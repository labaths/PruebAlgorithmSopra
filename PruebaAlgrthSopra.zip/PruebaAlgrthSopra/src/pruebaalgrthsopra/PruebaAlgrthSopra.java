
package pruebaalgrthsopra;
import Modelo.Persona;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author labaths
 */
public class PruebaAlgrthSopra {
static Persona[] tPersonas = new Persona[50];
    
    private static boolean esImpar(int num){
        if (num%2!=0)
            return true;
        else
            return false;
    }
    
    private static boolean esPar(int num){
        if (num%2==0)
            return true;
        else
            return false;
    }   
    
    private static void numPI(int num){
        if (esImpar(num)){
            System.out.println(num + " es impar");
            System.out.println("Numeros impares descendentes:");
            for (int i = num; i >0; i--) {
                if (esImpar(i)){
                    System.out.println(i);
                }
                
            }
        }else{
            System.out.println(num+ " es par");
            for (int i = num; i >0; i--) {
                if (esPar(i)){
                    System.out.println(i);
                }
                
            }
        }
    }  
    
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc= new Scanner(System.in);
        
        //--- 1. 
        System.out.println("----Primer caso-----");
        System.out.print("Escribe numero entero: ");
        int numero= sc.nextInt();
        numPI(numero);

        
        //--- 2.
        System.out.println("----Segundo caso-----");
        for (int i = 0; i < 50; i++) {
            Persona p = new Persona();
            System.out.print("Edad: ");
            p.setEdad(sc.nextInt());
            System.out.print("Sexo: (m/f)");
            p.setSexo(sc.next().charAt(0));
            tPersonas[i]=p;
            System.out.println();
        } 
        datos();
        System.out.println();
        
        
        //--- 3.
        System.out.println("----Tercer caso-----");
        System.out.print("Cuantas horas has trabajado: ");
        float horastrabjadas=sc.nextFloat();
        System.out.print("Cual es tu tárifa: ");
        float tarifa = sc.nextFloat();
        sueldo(horastrabjadas, tarifa);
        
        
        
    }
    
    private static void  datos(){
        int contMe=0, contMeM=0, contMeF=0, contMujeres=0;
        
        
        for (int i = 0; i < tPersonas.length; i++) {   
            if (tPersonas[i].getEdad() >=18){
                contMe++;
            }
            if (tPersonas[i].getSexo() == 'm' && tPersonas[i].getEdad() >=18){
                contMeM++;
            }
            if (tPersonas[i].getSexo() == 'f' && tPersonas[i].getEdad() <=18){
                contMeF++;
            }
            if (tPersonas[i].getSexo() == 'f' ){
                contMujeres++;
            }
        }
        System.out.println("Mayoría de edad: "+ contMe+ "      \tMenores de edad: "+ (50-contMe));
        System.out.println("Cantidad de personas masculinas mayores de edad: "+ contMeM);
        System.out.println("Cantidad de personas femeninas menores de edad: "+ contMeF);
        float porcMe = ((contMe*100)/50);
        System.out.println("Porcentaje que representan las personas mayores de edad respecto al total de personas: "+ porcMe +"%");
        float porMujeres = ((contMujeres*100)/50);
        System.out.println("Cantidad de personas femeninas menores de edad: "+ contMujeres+"%");
    }
     
    private static void sueldo(float horas, float tarifa){
        float horasExtra=0;
        if (horas>40){
            horasExtra = horas-40;
        }
        float sueldo = tarifa*40 + (horasExtra* (tarifa + (tarifa/2)));
        System.out.print("Sueldo total es: " + sueldo);
    }
}
